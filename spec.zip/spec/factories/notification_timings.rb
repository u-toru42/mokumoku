# frozen_string_literal: true

FactoryBot.define do
  factory :notification_timing do
    timing { 1 }
  end
end
