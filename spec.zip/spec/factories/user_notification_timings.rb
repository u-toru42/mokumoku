# frozen_string_literal: true

FactoryBot.define do
  factory :user_notification_timing do
    user { nil }
    notification_timing { nil }
  end
end
